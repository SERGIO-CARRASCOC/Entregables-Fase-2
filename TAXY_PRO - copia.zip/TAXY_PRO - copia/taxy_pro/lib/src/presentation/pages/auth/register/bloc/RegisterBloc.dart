import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/register/bloc/RegisterState.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  final formKey = GlobalKey<FormState>();

  RegisterBloc() : super(RegisterState()) {
    on<RegisterInitEvent>((event, emit) {
      emit(state.copyWith(formKey: formKey));
    });

    on<NameChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
            value: event.name.value,
            error: event.name.value.isEmpty ? 'Ingresa el nombre' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    on<LastnameChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
            value: event.lastname.value,
            error: event.lastname.value.isEmpty ? 'Ingresa el apellido' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    on<PhoneChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
            value: event.phone.value,
            error: event.phone.value.isEmpty ? 'Ingresa el telefono' : null,
          ),
          formKey: formKey,
        ),
      );
    });

    on<PasswordChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
            value: event.password.value,
            error: event.password.value.isEmpty
                ? 'Ingresa la nueva  contraseña'
                : event.password.value.length < 6
                    ? 'ingresa mas de 6 caracteres '
                    : null,
          ),
          formKey: formKey,
        ),
      );
    });

    on<ConfirmPasswordChanged>((event, emit) {
      emit(
        state.copyWith(
          name: BlocformItem(
              value: event.confermpassword.value,
              error: event.confermpassword.value.isEmpty
                  ? 'Confirma contraseña'
                  : event.confermpassword.value.length < 6
                      ? 'ingresa mas de 6 caracteres '
                      : event.confermpassword.value == state.password.value
                          ? 'La Contraseña No Coinciden'
                          : null),
          formKey: formKey,
        ),
      );
    });

    on<FormSubmit>((event, emit) {
      print('name: ${state.name.value}');
      print('LastName: ${state.lastname.value}');
      print('email: ${state.email.value}');
      print('phone: ${state.phone.value}');
      print('password: ${state.password.value}');
      print('confirmpassword: ${state.confirmPassword.value}');
    });
    on<FormReset>((event, emit) {
      state.formKey?.currentState?.reset();
    });
  }
}
