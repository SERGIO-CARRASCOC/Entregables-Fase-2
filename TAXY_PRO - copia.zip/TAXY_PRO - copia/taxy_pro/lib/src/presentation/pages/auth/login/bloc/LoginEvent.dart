import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

abstract class LoginEvent {}

class LoginInitEvent extends LoginEvent {}

class EmailChanged extends LoginEvent {
  final BlocformItem email;
  EmailChanged({required this.email});
}

class PasswordChanged extends LoginEvent {
  final BlocformItem password;
  PasswordChanged({required this.password});
}

class FormSubmit extends LoginEvent {}
