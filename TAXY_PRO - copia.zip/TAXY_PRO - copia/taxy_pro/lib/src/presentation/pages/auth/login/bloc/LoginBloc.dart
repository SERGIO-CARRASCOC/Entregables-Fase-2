import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginState.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final formKey = GlobalKey<FormState>();

  LoginBloc() : super(LoginState()) {
    on<LoginInitEvent>((event, emit) {
      emit(state.copyWith(formKey: formKey));
    });

    on<EmailChanged>((event, emit) {
      emit(
        state.copyWith(
            email: BlocformItem(
                value: event.email.value,
                error: event.email.value.isEmpty ? 'Ingresa tu Email' : null),
            formKey: formKey),
      );
    });

    on<PasswordChanged>((event, emit) {
      emit(state.copyWith(
          password: BlocformItem(
              value: event.password.value,
              error: event.password.value.isEmpty
                  ? 'Ingresa tu contraseña'
                  : event.password.value.length < 6
                      ? 'Miimo 6 caracteres '
                      : null),
          formKey: formKey));
    });

    on<FormSubmit>((event, emit) {
      print('Email: ${state.email.value}');
      print('Password: ${state.password.value}');
    });
  }
}
