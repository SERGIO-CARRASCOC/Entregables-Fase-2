import 'package:flutter/material.dart';

class DefaultButton extends StatelessWidget {
  Function() onPressed;
  String text;
  Color color;
  Color textcolor;
  EdgeInsetsGeometry margin;

  DefaultButton({
    required this.text,
    required this.onPressed,
    this.color = Colors.blue,
    this.textcolor = Colors.white,
    this.margin = const EdgeInsets.only(bottom: 60, left: 20, right: 20),
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      width: MediaQuery.of(context).size.width,
      //alignment: Alignment.center ,
      margin: margin,
      child: ElevatedButton(
          onPressed: () {
            onPressed();
          },
          style: ElevatedButton.styleFrom(backgroundColor: color),
          child: Text(
            text,
            style: TextStyle(
                color: textcolor, fontSize: 20, fontWeight: FontWeight.bold),
          )),
    );
  }
}
