import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';

class LoginState extends Equatable {
  final GlobalKey<FormState>? formKey;
  final BlocformItem email;
  final BlocformItem password;

  const LoginState({
    this.formKey,
    this.email = const BlocformItem(error: 'Ingresa un Email'),
    this.password = const BlocformItem(error: 'Ingresa tu contraseña'),
  });

  LoginState copyWith({
    GlobalKey<FormState>? formKey,
    BlocformItem? email,
    BlocformItem? password,
  }) {
    return LoginState(
      email: email ?? this.email,
      password: password ?? this.password,
      formKey: formKey ?? this.formKey,
    );
  }

  @override
  List<Object?> get props => [email, password];
}
