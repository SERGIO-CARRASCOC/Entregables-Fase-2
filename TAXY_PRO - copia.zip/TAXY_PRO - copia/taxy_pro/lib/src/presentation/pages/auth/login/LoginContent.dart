import 'package:flutter/material.dart';
import 'package:taxy_pro/main.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginBloc.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginEvent.dart';
import 'package:taxy_pro/src/presentation/pages/auth/login/bloc/LoginState.dart';
import 'package:taxy_pro/src/presentation/pages/auth/utils/BlocFormItem.dart';
import 'package:taxy_pro/src/presentation/pages/auth/witgets/DefaultButton.dart';
import 'package:taxy_pro/src/presentation/pages/auth/witgets/DefaultTextField.dart';

class LoginContent extends StatelessWidget {
  LoginState state;

  LoginContent(this.state);

  @override
  Widget build(BuildContext context) {
    return Form(
      key: state.formKey,
      child: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            color: const Color.fromARGB(55, 21, 26, 28),
            padding: EdgeInsets.only(left: 12),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _textLoginRotated(),
                  SizedBox(height: 100),
                  _textRegisterRotated(context),
                  SizedBox(height: 100),
                ]),
          ),
          Container(
            height: MediaQuery.of(context).size.height,
            margin: EdgeInsets.only(left: 60, bottom: 30),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [Colors.grey, Colors.black],
                ),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(35),
                    bottomLeft: Radius.circular(35))),
            child: Container(
              margin: EdgeInsets.only(left: 25, right: 25),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 50),
                    _textBienvenido('Bienvenido'),
                    _textBienvenido('Back...'),
                    _imageCar(),
                    _textLogin(),
                    DefaultTextField(
                        onChanged: (text) {
                          context.read<LoginBloc>().add(
                              EmailChanged(email: BlocformItem(value: text)));
                        },
                        validator: (value) {
                          return state.email.error;
                        },
                        text: 'Email',
                        icon: Icons.email_outlined),
                    DefaultTextField(
                        onChanged: (text) {
                          context.read<LoginBloc>().add(PasswordChanged(
                              password: BlocformItem(value: text)));
                        },
                        validator: (value) {
                          return state.password.error;
                        },
                        text: 'Password',
                        icon: Icons.lock_clock_outlined),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.1),
                    DefaultButton(
                      text: 'Iniciar Sesion ',
                      onPressed: () {
                        if (state.formKey!.currentState!.validate()) {
                          context.read<LoginBloc>().add(FormSubmit());
                        } else {
                          print('INGRESAR SUS DATOS');
                        }
                      },
                    ),
                    _separador(),
                    SizedBox(height: 10),
                    _textDontHavetAccount(context),
                    SizedBox(
                      height: 50,
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _separador() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 25,
          height: 1,
          color: Colors.white,
          margin: EdgeInsets.only(right: 5),
        ),
        Text(
          'O',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
          ),
        ),
        Container(
          width: 25,
          height: 1,
          color: Colors.white,
          margin: EdgeInsets.only(left: 5),
        ),
      ],
    );
  }

  Widget _textLogin() {
    return Text(
      'Login',
      style: TextStyle(
          fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold),
    );
  }

  Widget _textDontHavetAccount(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'no tienes cuenta?',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24),
        ),
        SizedBox(width: 20),
        GestureDetector(
          onTap: () {
            Navigator.pushNamed(context, 'register');
          },
          child: Text(
            'Registrate',
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24),
          ),
        ),
      ],
    );
  }

  Widget _imageCar() {
    return Container(
      alignment: Alignment.centerRight,
      child: Image.asset(
        'assets/img/taxypro.jpeg',
        width: 200,
        height: 200,
      ),
    );
  }

  Widget _textBienvenido(String text) {
    return Text(
      text,
      style: TextStyle(
          fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold),
    );
  }

  Widget _textRegisterRotated(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, 'register');
      },
      child: RotatedBox(
        quarterTurns: 1,
        child: Text(
          'Registro',
          style: TextStyle(color: Colors.white, fontSize: 28),
        ),
      ),
    );
  }

  Widget _textLoginRotated() {
    return RotatedBox(
      quarterTurns: 1,
      child: Text(
        'Login',
        style: TextStyle(
            color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
      ),
    );
  }
}
