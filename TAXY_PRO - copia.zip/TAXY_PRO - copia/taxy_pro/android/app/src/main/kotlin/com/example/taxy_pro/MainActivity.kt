package com.example.taxy_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
